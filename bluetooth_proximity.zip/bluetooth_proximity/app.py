import asyncio
import json
import ctypes
import time
from fastapi import FastAPI, WebSocket
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from bleak import BleakScanner

app = FastAPI()

# The MAC addresses of your devices
DEVICES = {
    "iphone15": "78:75:B7:D1:6A:9D",
    "custom": ""
}

# Global State
class AppState:
    active_device = DEVICES["iphone15"]
    threshold = -80
    action = "play_pause" 
    is_monitoring = True
    trigger_time = 10  # Custom timer time
    is_away = False
    time_away = 0
    current_rssi = -100
    last_seen_time = time.time()

state = AppState()
connected_clients = set()

# Windows Virtual Key Codes
VK_MEDIA_PLAY_PAUSE = 0xB3
VK_VOLUME_MUTE = 0xAD
KEYEVENTF_EXTENDEDKEY = 0x0001
KEYEVENTF_KEYUP = 0x0002

def press_key(vk_code):
    # Sends a proper hardware-level keypress event to Windows
    ctypes.windll.user32.keybd_event(vk_code, 0, KEYEVENTF_EXTENDEDKEY, 0)
    ctypes.windll.user32.keybd_event(vk_code, 0, KEYEVENTF_EXTENDEDKEY | KEYEVENTF_KEYUP, 0)

# Execute chosen action
def do_action():
    print(f"[ACTION] Executing: {state.action.upper()}")
    if state.action == "lock":
        ctypes.windll.user32.LockWorkStation()
    elif state.action == "play_pause":
        press_key(VK_MEDIA_PLAY_PAUSE)
    elif state.action == "mute":
        press_key(VK_VOLUME_MUTE)
    elif state.action == "none":
        print("No action configured.")

# Bluetooth Callback
def detection_callback(device, advertisement_data):
    if device.address.upper() == state.active_device.upper() and state.is_monitoring:
        state.current_rssi = advertisement_data.rssi
        state.last_seen_time = time.time()
        asyncio.create_task(broadcast_state())

async def broadcast_state():
    countdown = state.trigger_time - state.time_away
    if countdown < 0: countdown = 0
    
    message = json.dumps({
        "type": "state_update", 
        "rssi": state.current_rssi,
        "countdown": countdown if (state.current_rssi < state.threshold and state.current_rssi != -100) or (state.current_rssi == -100 and state.time_away > 0) else state.trigger_time,
        "is_away": state.is_away,
        "is_monitoring": state.is_monitoring
    })
    for client in list(connected_clients):
        try:
            await client.send_text(message)
        except:
            connected_clients.remove(client)

# Main proximity loop
async def proximity_monitor():
    scanner = BleakScanner(detection_callback)
    scanner_running = False
    print("Bluetooth Scanner initialized.")
    
    try:
        while True:
            await asyncio.sleep(1)
            
            # If monitoring is paused via UI, physically stop the Bluetooth scanner!
            if not state.is_monitoring:
                if scanner_running:
                    await scanner.stop()
                    scanner_running = False
                    print("Scanner hardware paused.")
                
                state.time_away = 0
                state.is_away = False
                state.current_rssi = -100
                await broadcast_state()
                continue
            
            # If monitoring is active but scanner isn't running, start it!
            if state.is_monitoring and not scanner_running:
                await scanner.start()
                scanner_running = True
                print("Scanner hardware started.")
            
            if time.time() - state.last_seen_time > 5:
                if state.current_rssi != -100:
                    state.current_rssi = -100
            
            if state.current_rssi < state.threshold or state.current_rssi == -100:
                state.time_away += 1
            else:
                state.time_away = 0
                state.is_away = False
            
            await broadcast_state()
            
            if state.time_away >= state.trigger_time and not state.is_away:
                print("Device crossed the threshold! Triggering Action!")
                do_action()
                state.is_away = True
                
    except asyncio.CancelledError:
        pass
    finally:
        if scanner_running:
            await scanner.stop()

# FastAPI Events
@app.on_event("startup")
async def startup_event():
    asyncio.create_task(proximity_monitor())

app.mount("/static", StaticFiles(directory="static"), name="static")

@app.get("/")
async def get():
    with open("static/index.html", "r", encoding="utf-8") as f:
        return HTMLResponse(f.read())

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    connected_clients.add(websocket)
    
    active_device_key = "iphone15"
    for key, mac in DEVICES.items():
        if mac.upper() == state.active_device.upper():
            active_device_key = key
            break
            
    await websocket.send_text(json.dumps({
        "type": "config",
        "device": active_device_key,
        "threshold": state.threshold,
        "action": state.action,
        "trigger_time": state.trigger_time,
        "is_monitoring": state.is_monitoring
    }))
    
    try:
        while True:
            data = await websocket.receive_text()
            msg = json.loads(data)
            
            if msg.get("type") == "update_config":
                if "device" in msg:
                    if msg["device"].startswith("custom:"):
                        mac = msg["device"].split("custom:")[1]
                        DEVICES["custom"] = mac
                        state.active_device = mac
                    else:
                        state.active_device = DEVICES[msg["device"]]
                if "threshold" in msg:
                    state.threshold = int(msg["threshold"])
                if "action" in msg:
                    state.action = msg["action"]
                if "trigger_time" in msg:
                    state.trigger_time = int(msg["trigger_time"])
                if "is_monitoring" in msg:
                    state.is_monitoring = msg["is_monitoring"]
                    
                state.is_away = False
                state.time_away = 0
                if not state.is_monitoring:
                    state.current_rssi = -100
    except:
        connected_clients.remove(websocket)
