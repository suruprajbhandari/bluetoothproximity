import asyncio
from bleak import BleakScanner

async def scan():
    print("Scanning for Bluetooth devices for 10 seconds...")
    print("Please make sure your iPhone screen is ON and AirPods case is OPEN.")
    
    # Discover devices with advertisement data (which contains RSSI)
    devices_dict = await BleakScanner.discover(timeout=10.0, return_adv=True)
    
    print("\n--- Found Devices ---")
    
    # devices_dict is { address: (BLEDevice, AdvertisementData) }
    # Create a list of tuples to sort by RSSI
    device_list = []
    for address, (device, adv_data) in devices_dict.items():
        device_list.append((device, adv_data.rssi))
        
    # Sort devices by signal strength (RSSI)
    device_list.sort(key=lambda x: x[1], reverse=True)
    
    count = 0
    for device, rssi in device_list:
        # Ignore weak and unnamed signals to reduce noise, unless they are very close
        if device.name or rssi > -65:
            name = device.name if device.name else "Unknown Device"
            print(f"[{count+1}] Name: {name:<20} | MAC: {device.address} | RSSI: {rssi} dBm")
            count += 1
            
    if count == 0:
        print("No strong signals found. Try keeping the devices closer to your PC.")
    else:
        print("\nNOTE: RSSI is the signal strength. Closer to 0 means it's nearer to your PC.")

if __name__ == "__main__":
    asyncio.run(scan())
