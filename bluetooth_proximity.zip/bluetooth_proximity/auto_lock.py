import asyncio
import ctypes
from bleak import BleakScanner

# This is your iPhone 15's Bluetooth Address that we found in your system!
IPHONE_MAC = "78:75:B7:D1:6A:9D"

# How weak the signal needs to get before we consider you "Away" (-85 is pretty far)
AWAY_THRESHOLD = -85  
# How many seconds you must be away before the PC locks
AWAY_TIME_SECONDS = 15  

async def monitor():
    print(f"Monitoring proximity for your iPhone 15...")
    print(f"Walk away from your PC with your phone to test the auto-lock!")
    print("Press Ctrl+C to stop.\n")
    
    time_away = 0
    is_locked = False
    
    def detection_callback(device, advertisement_data):
        nonlocal time_away, is_locked
        if device.address.upper() == IPHONE_MAC.upper():
            rssi = advertisement_data.rssi
            
            # Only print occasionally to reduce spam
            if time_away % 4 == 0:
                print(f"[iPhone 15] Signal Strength: {rssi} dBm")
                
            if rssi > AWAY_THRESHOLD:
                time_away = 0  # Reset timer because you are close!
                is_locked = False

    # Start the Bluetooth scanner
    scanner = BleakScanner(detection_callback)
    await scanner.start()
    
    try:
        while True:
            await asyncio.sleep(1)
            time_away += 1
            
            # If the phone is away for the threshold time, and we haven't locked it yet
            if time_away >= AWAY_TIME_SECONDS and not is_locked:
                print("\n[ALERT] iPhone lost or too far! Locking computer...")
                
                # This is the Windows API command to lock the screen (Win + L)
                ctypes.windll.user32.LockWorkStation()
                
                is_locked = True
                
    except KeyboardInterrupt:
        print("\nStopping monitor...")
    finally:
        await scanner.stop()

if __name__ == "__main__":
    try:
        asyncio.run(monitor())
    except KeyboardInterrupt:
        pass
